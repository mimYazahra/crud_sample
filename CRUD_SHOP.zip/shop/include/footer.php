<script>

 $('#menu .item-menu').click(function(){
	 b = true;
	 //if the sub-menu was active and displaying
	 if($(this).hasClass('active')){
		 $(this).removeClass('active');
		 b = false;
	 }
	 
	 //if the sub-menu was hidden:
	 if($('.sub-menu',this) && b){
		  $('#menu .item-menu').removeClass('active');
		 $(this).addClass('active');
	 }
 });

</script>

</div>
</body>
</html>