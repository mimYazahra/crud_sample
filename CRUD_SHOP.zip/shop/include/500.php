<div id="err500">
	<div class="title">500</div>
	<div class="subtitle">خطای سیستمی</div>
	
	
</div>


<style>
	#err500{
    text-align: center;
    padding: 10px;
    min-height: 500px;
    width: 800px;
    border-radius: 5px;
    margin: auto;
    background: #4d8ec7;
		line-height: 120px;

	}
	#err500 .title{
	color: red;
    line-height: 95px;
    margin-top: 194px;
    font-size: 188px;
	}
	#err500 .subtitle{
		font-size: 18px;
		color: black;
	}
	
</style>