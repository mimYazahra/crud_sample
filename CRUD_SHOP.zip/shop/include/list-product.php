<?php
	$limit = 4;
	$startpage = 0;
	$page = 1;
	if(isset($_REQUEST['page'])){
		$page = (int)$_REQUEST['page'];
		if($page > 1){
			$startpage = ($page - 1) * $limit;
		}
	}
	$c = runsql("select count(*) as c from product");
	$count = $c[0]['c'];
	$pagenum = 1;
	if($count > $limit){
		$pagenum = ceil($count/$limit);
	}

	$r = runsql("select product.*, concat(brand.name,' - ', brand.engname) as brandname from product, brand where product.idbrand = brand.idbrand order by idproduct asc limit $startpage, $limit");
?>
	
	
	<table class="table" width="100%">
		<thead>
			<tr>
				<th>ردیف</th>
				<th>کد محصول</th>
				<th>نام محصول</th>
				<th>نام انگلیسی محصول</th>
				<th>برند</th>
				<th>رنگ های موجود</th>
				<th>خلاصه مشخصات محصول</th>
				<th>عملیات</th>
			</tr>
		</thead>
		<tbody>
		
<?php
	$index = ($page * $limit) - $limit;
	foreach($r as $key){
		$index++;

		$colors = str_replace(" | ", ',', $key['colors']);
		$itmes = "";
		if(strlen($colors) > 0){
			$c = getrecord("tblcolor", "idcolor in ($colors)");
			foreach($c as $color){
				$itmes.='<div class="item" id="itemcolor"><div class="box-color" style="background:'.$color['value'].'"></div> </div>';
			}
			$colors = $itmes;
		}
		echo("
			<tr>
				<td>$index</td>
				<td>$key[idproduct]</td>
				<td>$key[name]</td>
				<td>$key[engname]</td>
				<td>$key[brandname]</td>
				<td id='color'>$colors</td>
				<td>$key[summary]</td>
				<td>
				<div class='buttons'>
					<div class='btn btn-info' onClick='showgallery($key[idproduct])'>تصاویر</div>
					<div class='btn btn-success' id='success'  onClick='setreview($key[idproduct])'>نقد و بررسی</div>
					<div class='btn btn-primary' id='success'  onClick='showproperties($key[idproduct])'>مشخصات</div>
					<div class='btn btn-danger' id='success'  onClick='store($key[idproduct])'>انبار</div>
				</div>
				</td>
			</tr>
		");
	}

?>

		</tbody>
	</table>


    <div class="number">
    	<?php
			for($i = 1; $i <= $pagenum; $i++){
				echo("
  					<a href='index.php?action=list-product&page=$i'>
						<div class='item-number'>$i</div>
					</a>
				");
			}
		?>
    </div>


<script>
	function showgallery(idp){
		$.ajax({
			url:'function/showgallery.php',
			data: 'idproduct='+idp,
			success: function(data){
			showpopup('نمایش تصاویر محصول', data);
			
			}
		});
	}

	function setreview(idp){
		$.ajax({
			url:'function/setreview.php',
			data: 'idproduct='+idp,
			success: function(data){
			showpopup('نقد و بررسی محصول', data);
			}
		});
	}
	
	function showproperties(idp){
		$.ajax({
			url:'function/showproperties.php',
			data: 'idproduct='+idp,
			success: function(data){
			showpopup('ثبت و مشاهده مشخصات', data);
			}
		});
	}
	
	function store(idp){
		$.ajax({
			url:'function/store.php',
			data: 'idproduct='+idp,
			success: function(data){
			showpopup('انبارداری', data);
			}
		});
	}
</script>





