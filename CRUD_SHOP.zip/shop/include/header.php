<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo($title) ?></title>
<link rel = "stylesheet" type="text/css" href="font/font.css"/>
<link rel = "stylesheet" type="text/css" href="font/font-awesome/font-awesome.css"/>
<script src="js/jquery.min.js"></script>
<link rel = "stylesheet" type="text/css" href="css/btn.css"/>
<link rel = "stylesheet" type="text/css" href="css/main.css?v=20"/>

</head>

<body dir="rtl">
	
	<div id="backgroundpopup">
			<div class="popup">
				<div class="close" onClick="hideall()">X</div>
				<div class="title">Title</div>
				<div class="body">Body</div>
			</div>
		</div>

	<script>
		function showpopup(titlehtml, bodyhtml){
			
			$('#backgroundpopup .popup .title').html(titlehtml);
			$('#backgroundpopup .popup .body').html(bodyhtml);

			$('#backgroundpopup').show();
		}
		
		function hideall(){
			$('#backgroundpopup').hide();

		}
	</script>

	<?php 
		include_once("include/menu.php");
	?>
	<div id="main">
		<div id="head">
			<?php 
				$r = getrecord("admins", "admin_id = '$idadmin'");
				$admin_name = $r[0]['name'].' '.$r[0]['family'];
				echo("<div class='nameuser'> <i class='icon-user'></i> $admin_name </div>");
				echo("<a href='login.php?action=signout' title='خروج از حساب کاربری'> <div class='signout'> <i class='icon-power-off'></i> </div> </a>");
			?>
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
