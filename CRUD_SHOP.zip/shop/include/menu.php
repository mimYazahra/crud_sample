<div id="menu">
	<?php 
		$r = getrecord("menu", 'subitem = 0');
		foreach($r as $key){
			$sub = getrecord("menu", "subitem = $key[menu_id]");
			if(count($sub) > 0){
				$subitem = true;
			} else {
				$subitem = false;
			}
			$icon = $key['icon'];
			if($key['url']== ''){
				$link = 'index.php';
			} else {
				$link = 'index.php?action='.$key['url'];
			}
			if($subitem == false){
				echo('<a href="'.$link.'">
				<div class="item-menu">
					<i class="'.$icon.'"></i>
					<div class="name-menu">'.$key['name'].'</div>
				</div>
				</a>');				
			} else {
				echo(
				'<div class="item-menu">
					<i class="'.$icon.'"></i>
					<div class="name-menu">'.$key['name'].'</div>
					<div class="showsubitem"> <i class="icon-chevron-sign-down"></i> </div>
					<div class="sub-menu">');
					foreach($sub as $keysub){
						$link = 'index.php?action='.$keysub['url'];
						$icon = $keysub['icon'];
						echo(
							'<a href="'.$link.'">
								<div class="item-menu">
									<i class="'.$icon.'"></i>
									<div class="name-menu">'.$keysub['name'].'</div>
								</div>
							</a>
						');
					}
					
				echo('
					</div>
				</div>');
			}

		}
	?>
	
</div>