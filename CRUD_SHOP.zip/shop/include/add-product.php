<div class="form">

	<div class="row">
		<div class="name">
			<label for="idcat">دسته بندی</label>
		</div>
		<div class="input">
			<select id = "idcat">
				<option value="0" selected disabled>
				لطفا یک مورد را انتخاب کنید</option>
				<?php
					$r = getrecord("tblcat", "subid = 0");
					foreach($r as $key){
					echo("<option value = '$key[idcat]'> - $key[name] </option>");
					$s = getrecord("tblcat", "subid = $key[idcat]");
						foreach($s as $sub){
							echo("<option value = '$sub[idcat]'> -- $sub[name] </option>");
							$s2 = getrecord("tblcat", "subid=$sub[idcat]");
							foreach($s2 as $subitem){
								echo("<option value = '$subitem[idcat]'> --- $subitem[name] </option>");
							}		
						}		
					}		
				?>

			</select>
		</div>
	</div>
	

	<div class="row">
		<div class="name">
			<label for="name">نام محصول</label>
		</div>
		<div class="input">
			<input type="text" id="name" placeholder="نام محصول..."/>
		</div>
	</div>
	
	<div class="row">
		<div class="name">
			<label for="engname">نام انگلیسی محصول</label>
		</div>
		<div class="input">
			<input type="text" id="engname" placeholder="نام انگلیسی محصول..."/>
		</div>
	</div>
	
	<div class="row">
		<div class="name">
			<label for="summary">خلاصه مشخصات</label>
		</div>
		<div class="input">
			<textarea id="summary" placeholder="خلاصه مشخصات..."></textarea>
		</div>
	</div>
	
	<div class="row">
		<div class="name">
			<label for="idbrand">برند</label>
		</div>
		<div class="input">
			<select id = "idbrand">
				<option selected disabled value="0">
					لطفا یک مورد را انتخاب کنید
				</option>
				<?php
					$b=getrecord("brand");
					foreach($b as $brand){
						echo("<option value=$brand[idbrand]>$brand[name] - $brand[engname] </option>");
					}
				?>
			</select>
		</div>
	</div>
		
	<div class="row">
		<div class="name">
			<label for="colors">رنگ ها</label>
		</div>
		<div class="input">
		
			<?php
				$c=getrecord("tblcolor");
				foreach($c as $color){
					echo('
					<div class="object">
						<input type="checkbox" 
						value="'.$color['idcolor'].'"
						id="color-'.$color['idcolor'].'" name="colors" 
						/> 
						<label
						for="color-'.$color['idcolor'].'">'.$color['name'].'
						</label>
						<div class="box-color" style="background:'.$color['value'].'"></div> 
					</div>');
				}
			?>
		</div>
	</div>
	
	<div class="row">
		<div class="name">
			<label for="status">وضعیت</label>
		</div>
		<div class="input">
			<select id = "status">
				<option value="published">عرضه شده</option>
				<option value="coming-soon">به زودی</option>
				<option value="old">توقف تولید</option>
				<option value="test" selected>آزمایشی</option>

			</select>
		</div>
	</div>
	
	<div class="row">
		<div class="btn btn-success btn-block" onClick="addproduct()">افزودن محصول</div>
	</div>

	
</div>

<script>
	
	function addproduct(){
		var idcat=$('#idcat option:selected').val();
		var name = $('#name').val();
		var engname = $('#engname').val();
		var summary = $('#summary').val();
		var idbrand = $('#idbrand option:selected').val();
		var colors = $('input[name="colors"]:checked').map(function(index, element){
			return this.value;
		}).get().join(' | ');
		var status = $('#status option:selected').val();
		
		if(idcat!='0' && name.length >= 3 && engname.length >= 3){
			$.ajax({
				url:'function/addproduct.php',	data:'name='+name+'&engname='+engname+'&summary='+summary+'&idbrand='+idbrand+'&colors='+colors+'&idcat='+idcat+'&status='+status,
				success: function(data){
					alert(data);
				}
			});
		} else {
			alert('مقادیر را بررسی کنید');
		}
	}
	
</script>












