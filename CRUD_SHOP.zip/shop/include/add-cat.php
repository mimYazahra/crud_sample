
	<script src="js/jquery.min.js"></script>


	<div class="form">

	<div class="row">
		<div class="name">
			<label for = "name">نام دسته بندی</label>
		</div>
		<div class="input">
			<input type="text" id="name" placeholder="نام دسته بندی"/>
		</div>
	</div>
	
	<div class="row">
		<div class="engname">
			<label for = "engname">نام انگلیسی</label>
		</div>
		<div class="input">
			<input type="text" id="engname" placeholder="نام انگلیسی"/>
		</div>
	</div>
	
	<div class="row">
		<div class="engname">
			<label for = "subid">انتخاب سرشاخه</label>
		</div>
		<div class="input">
			<select id="subid">
				<option value="0" selected>سرشاخه</option>
				<?php
					$r = getrecord("tblcat", "subid = 0");
					foreach($r as $key){
						echo("<option value = '$key[idcat]'> - $key[name] </option>");
						$s = getrecord("tblcat", "subid = '$key[idcat]'");
						foreach($s as $sub){
							echo("<option value = '$sub[idcat]'> -- $sub[name] </option>");
						}
					}
				?>
			</select>
		</div>
	</div>
	<div class="row">
		<div class="btn btn-success" onClick="addcategory()">ثبت</div>
	</div>
	
</div>


<script>
	function addcategory(){


		var name = $('#name').val();
		var engname = $('#engname').val();
		var subid = $('#subid option:selected').val();
		
		if(name.length >= 3 && engname.length >=3 && subid){
				$.ajax({
				url:'function/addcat.php',
				type:'POST',
				data:'name='+name+'&engname='+engname+"&subid="+subid,
				success: function(data){
				 alert(data);
				}
			});
	
			
		} else{
			alert("مقادیر را بررسی کنید");
		}
	}
	
	
</script>












