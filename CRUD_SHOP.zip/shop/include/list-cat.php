<?php

	$r = getrecord("tblcat", "subid = 0");
	foreach($r as $key){
		echo("
			<div class = 'item-cat active' data-tab='false' data-id = '$key[idcat]'>
				<div class = 'name'> $key[name] </div>");
		$s = getrecord("tblcat", "subid = $key[idcat]");
		//this is for displayin sub=items
		if(count($s)>0){
			echo('<div class="arrow"> <i class="icon-arrow-down"></i></div>');
		}
		echo("</div>");
			if(count($s)>0){
			echo('<div class="subitem" data-id = '.$key['idcat'].'>'); 
				foreach($s as $sub){
					echo("
						<div class = 'item-cat' data-tab='false' data-id = '$sub[idcat]'>
							<div class = 'name'> $sub[name] </div>	
					");
					//this is for displayin sub-item of sub=items
					$s2 = getrecord("tblcat", "subid = $sub[idcat]");
					if(count($s2)>0){
						echo('<div class="arrow"> <i class="icon-arrow-down"></i></div>');
					}
					echo("</div>");

					if(count($s2)>0){
						echo('<div class="subitem" data-id = '.$sub['idcat'].'>'); 
							foreach($s2 as $sub2){
								echo("
									<div class = 'item-cat'>
										<div class = 'name'> $sub2[name] </div>	
									</div>
								");
							}
						echo('
							</div>
						</div>');
					}			
				}
		}

	}

?>




<script>
//	idtab=$(this).data('tab');	
//	$('#tabs .item-tab').removeClass('active');
//	$('#bodytab .item-body-tab').removeClass('active');
//	$(this).addClass('active');
//	$('#'+idtab).addClass('active');
	
	$('.item-cat').click(function(){
		idcat = $(this).data('id');
//		idtab=$(this).data('tab');	
////		alert('idtab='+idtab+', idcat='+idcat);
//		if(idtab == false){
//			$('.arrow',this).css({'transform':'rotate(180deg)'});
////			$('#'+idtab) =true;
////			idtab = true;
//			
//			$(this).data('tab')=true;
//		} else{
////			$('#'+idtab) =false;
////			idtab = false;
//			$(this).data('tab')=false;
//			$('.arrow',this).css({'transform':'rotate(360deg)'});
//		}
//		if($('#'+idcat).hasClass('active')){
//
//			$('#'+idcat+'.item-cat').removeClass('active');
//
//			$('.arrow',this).css({'transform':'rotate(360deg)'});
//		} else {
//			$('#'+idcat +'.item-cat').addClass('active');
//			$('.arrow',this).css({'transform':'rotate(180deg)'});
//		}
		
		$('.subitem[data-id="'+idcat+'"]').toggleClass("open");
		$('.subitem[data-id="'+idcat+'"]').toggle();
		if($('.subitem[data-id="'+idcat+'"]').hasClass("open")){
			$('.arrow',this).css({'transform':'rotate(180deg)'});
		} else {
			$('.arrow',this).css({'-webkit-transform': 'rotate(360deg)'});
		}

		
	});

</script>










