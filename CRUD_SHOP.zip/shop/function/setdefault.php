<?php include ("../config-admin.php");?>

<?php
	if(isset($_REQUEST['idimage'])){
		$idimage = sqi($_REQUEST['idimage']);
		$r=getrecord("tblimages","idimage='$idimage'");
		if(count($r)>0){
			$idtable = $r[0]['idtable'];
			$urlimg = $r[0]['url'];
		updaterecord("tblimages",array("primari"=>0),"idtable='$idtable' and nametable = 'product'");
		updaterecord("tblimages",array("primari"=>1),"idimage='$idimage'");
		updaterecord("product",array("pic"=>$urlimg),"idproduct='$idtable'");
		echo(true);
		} else{
			echo('error');
		}
	} else {
		echo('error');
	}
?>