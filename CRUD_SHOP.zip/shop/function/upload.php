<?php include ("../config-admin.php");?>
<?php
	$json=array();
	$json['status']='error';
	if(isset($_REQUEST['id']) and isset($_REQUEST['table'])){
		$nametable=sqi($_REQUEST['table']);
		$idtable=sqi($_REQUEST['id']);
		if(isset($_FILES['file']) and isset($_FILES['file']['name'])){
			$file=$_FILES['file'];
			$namefile=$file['name'];
			$ext=strtolower(pathinfo($namefile,PATHINFO_EXTENSION));
			$upload=1;
			$allowedext=array('---','jpg','png','jpeg');
			if(! array_search($ext,$allowedext) ){
				$json['error']='فرمت فایل مجاز نیست';
				$upload=0;
			}
			if( $file['size'] > (1024*1024*5) ){
				$json['error']='حجم فایل بیش از حد مجاز میباشد';	
				$upload=0;
			}
			if($upload==1){
				$target='../../content/product/'.$namefile;
				$urlimg='content/product/'.$namefile;
				if(file_exists($target)){
					$namenew=date('Y-n-j-H-i-s').rand(1024,999999);
					$target='../../content/product/'.$namenew.$ext;	
					$urlimg='content/product/'.$namenew.$ext;
				}
				move_uploaded_file($file['tmp_name'],$target);
				$pirmary=0;
				if($nametable=='product'){
					$r=getrecord("tblimages","idtable='$idtable' and nametable='product'");
					if(count($r)==0){
						$pirmary=1;
						updaterecord("product",array("pic"=>$urlimg),"idproduct='$idtable'");
						 
					}
				}
				addrecord("tblimages",
					array(
						"idtable"=>$idtable,
						"nametable"=>$nametable,
						"url"=>$urlimg,
						"primari"=>$pirmary,
						"iduser"=>$idadmin  
					)
				);
				$json['status']='ok';
				$json['urlimg']=$urlimg;
			}
		}else{
			$json['error']='فایل ها ارسالی اعتبار است';
		}	
	}else{
		$json['error']='پارامتر های ارسالی فاقد اعتبار میباشد';	
	}
	header("Content-Type: application/json; charset=utf-8");
	echo json_encode($json,JSON_UNESCAPED_UNICODE);
?>