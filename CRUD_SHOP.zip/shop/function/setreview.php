<?php include ("../config-admin.php");?>
<?php
	if(isset($_REQUEST['idproduct'])){
		$idproduct=(int) $_REQUEST['idproduct'];
		
	}else{
		echo 'متاسفانه پارامتر های ارسالی کامل نمی باشند';
		exit();
	}
	$r=getrecord("product","idproduct='$idproduct'");
	if(count($r)==0){
		echo 'متاسفانه چنین محصولی وجود ندارد';
		exit();
	}
	$des=$r[0]['des'];
?>
<link rel="stylesheet" type="text/css" href="assets/textarea/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/froala_editor.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/froala_editor.pkgd.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/froala_style.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/char_counter.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/video.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/colors.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/draggable.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/emoticons.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/file.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/fullscreen.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/help.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/image.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/image_manager.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/line_breaker.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/quick_insert.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/special_characters.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/plugins/table.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/third_party/embedly.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/third_party/spell_checker.min.css">
<link rel="stylesheet" type="text/css" href="assets/textarea/css/codemirror.min.css">
<div id='edit' style="margin-top: 30px;">
	<?php echo $des; ?>
    
</div>
<br/>
<div class="btn btn-success btn-block" onClick="savereview()">ثبت و ذخیره نقد بررسی</div>
<script type="text/javascript" src="assets/textarea/js/codemirror.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/xml.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/froala_editor.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/align.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/char_counter.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/code_beautifier.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/code_view.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/colors.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/draggable.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/emoticons.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/entities.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/file.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/font_family.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/font_size.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/forms.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/fullscreen.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/help.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/image.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/image_manager.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/inline_style.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/line_breaker.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/link.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/lists.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/paragraph_format.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/paragraph_style.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/print.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/quick_insert.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/quote.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/save.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/special_characters.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/table.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/url.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/video.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/plugins/word_paste.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/third_party/embedly.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/third_party/image_aviary.min.js"></script>
<script type="text/javascript" src="assets/textarea/js/third_party/spell_checker.min.js"></script>



<script>
    $(function(){
      $('#edit').froalaEditor()
    });
	function savereview(){
		var des	= $('.fr-element.fr-view').html();
		$.ajax({
			url:'function/updatereview.php',
			data:'idp=<?php echo $idproduct; ?>&des='+des,
			type:"POST",
			success: function(data){
				alert(data);
				hideall();
			}	
			
		})
		
	}
  </script>




