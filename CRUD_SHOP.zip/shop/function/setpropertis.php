<?php 
	include ("../config-admin.php");
	if(isset($_REQUEST['idproduct']) ){
		$idp=(int) sqi($_REQUEST['idproduct']);
		//var_dump($_REQUEST);
		foreach($_REQUEST as $key=>$value){
			$p=explode('-',$key);
			if(count($p)==2 and @$p[0]=='inputpropertis'){
				$idpropertis=$p[1];
				delete_record("tblperproduct","idpropertis='$idpropertis' and idproduct='$idp'");
				if($value!=""){
					$d=addrecord("tblperproduct",array("value"=>$value,"idpropertis"=>$idpropertis,"idproduct"=>$idp));
				}
			}
		} 
		
		echo true;
	}else{
		echo 'error';	
	}
?>