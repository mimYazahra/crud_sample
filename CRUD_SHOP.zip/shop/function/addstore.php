<?php 
	include("../config-admin.php");


//	var_dump(isset($_REQUEST['name']) and isset($_REQUEST['engname']) and isset($_REQUEST['idcat']) and isset($_REQUEST['summary'])  and isset($_REQUEST['status']) and isset($_REQUEST['idbrand']));

	if(isset($_REQUEST['idproduct']) and isset($_REQUEST['idcolor']) and isset($_REQUEST['garanti']) and isset($_REQUEST['price_buy']) and isset($_REQUEST['price_sale']) and isset($_REQUEST['tedad']) and isset($_REQUEST['date_offer'])  and isset($_REQUEST['price_offer'])){

		$idproduct = sqi($_REQUEST['idproduct']);
		$idcolor = sqi($_REQUEST['idcolor']);
		$garanti = sqi($_REQUEST['garanti']);
		$price_buy = (int) sqi($_REQUEST['price_buy']);
		$price_sale = (int) sqi($_REQUEST['price_sale']); 
		
		if($price_sale < $price_buy){
			exit('قیمت فروش از قیمت خرید کمتر است!');
		}
		
		$tedad = (int) sqi($_REQUEST['tedad']); 
		$date_offer = sqi($_REQUEST['date_offer']);  
		$price_offer = (int) sqi($_REQUEST['price_offer']);  
		
		if($date_offer == '') $date_offer = '1990-01-01';
		
		$iduser = $idadmin;

		$d = addrecord("tblstore", array("idproduct" => $idproduct, "idcolor" => $idcolor, "garanti" => $garanti, "price_buy" => $price_buy, "price_sale" => $price_sale, "tedad" => $tedad, "date_offer" => $date_offer, "price_offer" => $price_offer));

		if($d){
			echo(1);		
		
		} else {
			echo('failed to add!');
		}

	} else {
		echo ('error');
	}
?>