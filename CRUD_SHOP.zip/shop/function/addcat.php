<?php 
	include("../config-admin.php");

	if(isset($_REQUEST['name']) and isset($_REQUEST['engname']) and isset($_REQUEST['subid'])){

		$name = sqi($_REQUEST['name']);
		$subid = sqi($_REQUEST['subid']);
		$engname = sqi($_REQUEST['engname']);

		$r = getrecord("tblcat", "name = '$name' and engname = '$engname' and subid = '$subid'");
		if(count($r) > 0){
			echo('قبلا وارد شده');
		} else {
			$d = addrecord("tblcat", array("name" => $name, "engname" => $engname, "subid" => $subid));

			if($d){
				echo('successfully added!');
			} else {
				echo('failed to add!');
			}
		}

	} else{
		echo ('error');
	}
?>
