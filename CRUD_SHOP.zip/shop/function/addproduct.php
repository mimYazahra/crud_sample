<?php 
	include("../config-admin.php");


//	var_dump(isset($_REQUEST['name']) and isset($_REQUEST['engname']) and isset($_REQUEST['idcat']) and isset($_REQUEST['summary'])  and isset($_REQUEST['status']) and isset($_REQUEST['idbrand']));

	if(isset($_REQUEST['name']) and isset($_REQUEST['engname']) and isset($_REQUEST['idcat']) and isset($_REQUEST['summary']) and isset($_REQUEST['colors']) and isset($_REQUEST['status']) and isset($_REQUEST['idbrand'])){

		$name = sqi($_REQUEST['name']);
		$idcat = sqi($_REQUEST['idcat']);
		$engname = sqi($_REQUEST['engname']);
		$summary = sqi($_REQUEST['summary']);
		$colors = sqi($_REQUEST['colors']); 
		$status = sqi($_REQUEST['status']); 
		$idbrand = sqi($_REQUEST['idbrand']);  
		
		$iduser = $idadmin;

		$r = getrecord("product", "name = '$name' and engname = '$engname' and idcat = '$idcat'");
		if(count($r) > 0){
			if($r === false){
				echo('error');
			} else {
				echo('قبلا وارد شده');
			}
		} else {
			$d = addrecord("product", array("name" => $name, "engname" => $engname, "idcat" => $idcat, "iduser" => $iduser, "summary" => $summary, "colors" => $colors, "idbrand" => $idbrand, "status" => $status));

			if($d){
				echo('successfully added!');
			} else {
				echo('failed to add!');
			}
		}

	} else {
		echo ('error');
	}
?>