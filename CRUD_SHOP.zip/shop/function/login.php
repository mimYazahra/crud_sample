<?php 
$login = true;
include("../config-admin.php");

if(isset($_REQUEST['username']) and isset($_REQUEST['password'])){
	$username = sqi($_REQUEST['username']);
	$password = md5(sqi($_REQUEST['password']));
	$r = getrecord('admins',"username = '$username' and password = '$password'");
//	var_dump($r);
	if(count($r)>0){
		$_SESSION['admin_id'] = $r[0]['admin_id']; 
		$_SESSION['aa'] = $username;
		$idadmin = $_SESSION['admin_id'];
		echo($idadmin);
	} else {
		echo('نام کاربری یا رمز عبور اشتباه است.');
	}
} else{
	echo 0;
}
?>
