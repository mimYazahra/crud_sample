<?php include ("../config-admin.php");?>

<?php
	if(isset($_REQUEST['idproduct'])){
		$idproduct = (int) $_REQUEST['idproduct'];
		
	}else{ 
		echo 'متاسفانه پارامترهای ارسال شده کامل نمی باشد';
		exit();
	}

$p = getrecord("product", "idproduct = $idproduct");
if(count($p) == 0) 
	exit('error');
$product = $p[0];
$colors = str_replace(' | ', ',', $product['colors']);

?>

<table class="table">
	<thead>
		<tr>
			<th>ردیف</th>
			<th>رنگ</th>
			<th>گارانتی</th>
			<th>قیمت خرید</th>
			<th>قیمت فروش</th>
			<th>تعداد موجود</th>
			<th>تاریخ شروع پیشنهاد ویژه</th>
			<th>قیمت در پیشنهاد ویژه</th>
		</tr>
	</thead>
	
	<tbody>
		<?php
			$store = getrecord("tblstore", "idproduct='$idproduct'");
			$i = 1;
		foreach($store as $key){
			$color = getrecord("tblcolor", "idcolor=$key[idcolor]");
			$color = $color[0];
			echo "
				<tr>
					<td> $i </td>
					<td> $color[name] </td>
					<td> $key[garanti] </td>
					<td> $key[price_buy] </td>
					<td> $key[price_sale] </td>
					<td> $key[tedad] </td>
					<td> $key[date_offer] </td>
					<td> $key[price_offer] </td>
				</tr>
			";
			$i++;
			
		}
		?>
		<tr>
			<form>
				<td> <?php echo $i; ?> </td>
				<td>
					<?php
					if(strlen($colors) > 0){

						$c = getrecord("tblcolor", "idcolor in ($colors)");

						foreach($c as $color){
							echo('
							<div class="object">  
								<input type="radio" 
								value="'.$color['idcolor'].'"
								id="color-'.$color['idcolor'].'" name="idcolor" 
								/> 
								<label
								for="color-'.$color['idcolor'].'">'.$color['name'].'
								</label>
								<div class="box-color" style="background:'.$color['value'].'"></div> 
							</div>');
						}
					}
					?>
				</td>
				<td>
					<input type="text" id="garanti" placeholder="گارانتی"
				</td>
				<td>
					<input type="number" id="price_buy" placeholder="قیمت خرید"
				</td>
				<td>
					<input type="number" id="price_sale" placeholder="قیمت فروش"
				</td>
				<td>
					<input type="number" id="tedad" placeholder="تعداد"
				</td>
				<td>
					<input type="date" id="date_offer" placeholder="تاریخ فروش ویژه"
				</td>
				<td>
					<input type="number" id="price_offer" placeholder="قیمت فروش ویژه"
				</td>
				
				
			</form>
		</tr>
		
		
	</tbody>
	
</table>

<div class="btn btn-success btn-block" onclick="addstore()">افزودن</div>


<script>
	function addstore(){
		var idcolor= $('input[name="idcolor"]:checked').val();
		if(!idcolor){
			alert('لطفا رنگ را انتخاب کنید.');
		}
		var garanti = $('#garanti').val();
		var price_buy = $('#price_buy').val();
		var price_sale = $('#price_sale').val();
		if(price_sale < price_buy){
			alert('قیمت فروش کمتر از قیمت خرید انتخاب شده!');
		}
		var tedad = $('#tedad').val();
		var date_offer = $('#date_offer').val();
		var price_offer = $('#price_offer').val();
		if(price_buy.length > 4 && price_sale.length > 4
		  && tedad > 0){
			$.ajax({
				url:'function/addstore.php',
				data:'idproduct=<?php echo $idproduct; ?> &idcolor=' + idcolor + '&garanti=' + garanti + '&price_buy=' + price_buy + '&price_sale=' + price_sale + '&tedad=' + tedad + '&date_offer=' + date_offer + '&price_offer=' + price_offer,
				type: 'post',
				success:function(data){
					
					if(data == 1){
						$('#backgroundpopup .popup .body').load('function/store.php?idproduct=<?php echo $idproduct; ?>');	
						data = 'successfully added!';
					}
				alert(data);
				}
			})
		} else {
			alert('لطفا فیلدها را کامل کنید!');
		}
	}
</script>

















