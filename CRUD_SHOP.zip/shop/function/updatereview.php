<?php include ("../config-admin.php");?>
<?php
	if(isset($_REQUEST['idp']) and isset($_REQUEST['des'])){
		$idp=(int) sqi($_REQUEST['idp']);
		$des=sqi($_REQUEST['des']);
		updaterecord("product",array("des"=>$des),"idproduct='$idp'");
		echo 'با موفقیت بروزرسانی شد';
	}

?>