<?php include ("../config-admin.php");?>

<?php
	if(!isset($_REQUEST['idproduct'])){
		exit('error');	
	}
	$idp=sqi($_REQUEST['idproduct']);
	$p=getrecord("tblpropertis","subid=0");
	echo '<form class="form" method="post" id="frmpropertis">';
	echo '<input type="hidden" name="idproduct" value="'.$idp.'"/>';
	foreach($p as $key){
		echo '
		<Div class="item-per">
			<div class="arrow"><i class="icon-chevron-sign-down"></i></div>
			<div class="subject">'.$key['name'].'</div>
			<div class="body">';
			$s=getrecord("tblpropertis","subid=$key[idpropertis]");
			foreach($s as $sub){
				$val=getrecord("tblperproduct","idpropertis='$sub[idpropertis]'  and idproduct='$idp' ");
				$value='';
				if(count($val)>0){
					$value=$val[0]['value'];	
				}
				echo '
					<div class="row">
						<div class="name">'.$sub['name'].'</div>
						<div class="input">
							<input type="text" placeholder="'.$sub['name'].'" name="inputpropertis-'.$sub['idpropertis'].'" value="'.$value.'" />
						</div>
					</div>
				';
				
		
				
					
				
			}
				
	echo	'</div>
		</div>';	
	}
		echo '<button type="submit" class="btn btn-success btn-block" id="apply-propertis">ثبت مشخصات</button>';
		echo('</form>');

?>

<style>
	#apply-propertis {
		width: 99%;
	}
	.item-per{margin: 5px; background: #ebe7ff; border-radius: 5px; overflow: hidden;}
	.item-per .arrow{
		float: left;
		color: white;
		height: 28px;
		width: 28px;
		font-size: 20px;
		transition: all .3s;
		text-align: center;
		margin: 3px 0px;
		cursor: pointer;}
	.item-per .subject{padding: 5px; background: #de3d3d;
		color: white; cursor: pointer;
	}
	.item-per .subject:hover{background: #bf0000;}
	
	.item-per .body{padding: 5px; display: none;}
	.item-per.active .body{display: block; transition: all 0.4s;}
	.item-per.active .arrow{transform: rotate(180deg); }
	

</style>
<script>
	$('.item-per .subject').click(function(){
		self=$(this).parent();
		if($(self).hasClass('active')){
			$(self).removeClass('active');
		} else {
			$(self).addClass('active');
		}
	});
	
	$('.item-per .arrow').click(function(){
		self=$(this).parent();
		if($(self).hasClass('active')){
			$(self).removeClass('active');
		} else {
			$(self).addClass('active');
		}
	});
	
		$('#frmpropertis').submit(function(){
		$.ajax({
			url:'function/setpropertis.php',
			data:$('#frmpropertis').serialize(),
			type:'post',
			success: function(data){
				if(data==true){
					alert("ثبت مشخصات به درستی صورت گرفت.");
					 hideall();
				}else{
					alert('خطا در ثبت مشخصات');
					
				}
			}
		});	
		return false;
	});
	
</script>









